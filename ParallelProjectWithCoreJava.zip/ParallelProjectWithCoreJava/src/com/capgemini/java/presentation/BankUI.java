package com.capgemini.java.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.exception.BankException;
import com.capgemini.java.service.BankService;
import com.capgemini.java.service.BankServiceImpl;

public class BankUI {

	private static final String Name = null;

	public static void main(String[] args) {
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = new Scanner(System.in);
		do {

			System.out.println("****** Welcome To The Bank ******");
			System.out.println("1.Create The Account");
			System.out.println("2.Deposit");
			System.out.println("3.Show The Balance");
			System.out.println("4.Withdrawing");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print The Transaction");
			System.out.println("7. Exit");
			BankService service=new BankServiceImpl();
			int choice = 0;
			boolean choiceFlag = false;
			do {
				System.out.println("Enter Input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
				
					switch(choice) {
					case 1:{
					System.out.println("Enter the Name:");
				    String name=scanner.next();
				    System.out.println("Enter the Mobile number:");
				    long mobile=scanner.nextLong();
				    System.out.println("Enter tha balance:");
				    double balance=scanner.nextDouble();
					System.out.println("enter the gender:");
					String gender=scanner.next();
					BankAccount account=new BankAccount(0, balance, name, mobile);
                 long customerId=service.addAccountDetails(account);
                 System.out.println("Account recreated successfully with Id:"+customerId);
					}break;
					case 2:
					{
						
					}
		
					}
	} catch (InputMismatchException exception) {
		choiceFlag = false;
		System.err.println("input should contain only digits");
	}
} while (!choiceFlag);

		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);
	scanner.close();
}
	}


