package com.capgemini.java.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.dao.BankDAO;
import com.capgemini.java.dao.BankDaoImpl;
import com.capgemini.java.exception.BankException;

public class BankServiceImpl implements BankService {
       BankDAO dao=new BankDaoImpl();
	@Override
	public int addAccountDetails(BankAccount account) {
		
		return dao.addAccountDetails(account);
	}

	@Override
	public int addTransactionDetails(Transaction transaction) {
		
		return 0;
	}

	@Override
	public Map<Integer, BankAccount> getAllAccountDetails() {
		
		return null;
	}

	@Override
	public Map<Integer, Transaction> getAllTransactionDetails() {
		
		return null;
	}

	public boolean isNameValid(String name) {
		Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}
	public boolean isPhoneValid(long phone) {
		String mobile=String.valueOf(phone);
		Pattern mobileptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match=mobileptn.matcher(mobile);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}
public boolean validateAccountNo(String account) throws BankException{
	
	String account1=String.valueOf(account);
	Pattern accountptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
	Matcher match=accountptn.matcher(account1);
	if(match.matches()) {
		return true;
	}
	return false;
	
}
	
	
}
