package com.capgemini.java.service;

import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankService {

	int addAccountDetails(BankAccount account);
	int addTransactionDetails(Transaction transaction);
	public Map<Integer, BankAccount> getAllAccountDetails();
	public Map<Integer, Transaction> getAllTransactionDetails();
	

}
