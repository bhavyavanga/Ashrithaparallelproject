package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;

public class BankDaoImpl implements BankDAO {
	Map<Integer, BankAccount> accountMap=new HashMap<Integer, BankAccount>();

	@Override
	public int addAccountDetails(BankAccount account) {
		double Number=Math.random()*1000000000;
		int accountId=(int) Number;
		accountMap.put(accountId, account);
		return accountId;
	}

	@Override
	public int addTransactionDetails(Transaction transaction) {
		
		return 0;
	}

	@Override
	public Map<Integer, BankAccount> getAllAccountDetails() {
		
		return null;
	}

	@Override
	public Map<Integer, Transaction> getAllTransactionDetails() {
		
		return null;
	}

}
