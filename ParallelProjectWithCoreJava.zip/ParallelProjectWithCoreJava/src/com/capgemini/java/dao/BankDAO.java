package com.capgemini.java.dao;

import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;

public interface BankDAO {
	
	int addAccountDetails(BankAccount account);
	int addTransactionDetails(Transaction transaction);
	public Map<Integer, BankAccount> getAllAccountDetails();
	public Map<Integer, Transaction> getAllTransactionDetails();

}
